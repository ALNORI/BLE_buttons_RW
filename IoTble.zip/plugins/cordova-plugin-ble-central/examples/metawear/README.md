## MetaWare

Example using mbientlab's [MetaWare](http://mbientlab.com/product/).

Read values from the button press on the MetaWear.

Operate the Motor and Buzzer on the MetaWare.

Hardware

 * [MetaWare](http://mbientlab.com/product/)

Install

    $ cordova platform add android ios
    $ cordova plugin add cordova-plugin-ble-central
    $ cordova run

